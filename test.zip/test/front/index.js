const data = fetch('../back/data/netwrix_data_classification/hardware_requirements.json')
    .then(res => res.json())
    .then(data => {
        console.log(data);
        document.getElementById('content').innerHTML = data[0].t0 
    })

